<html>


<?php
session_start();
?>


<head>
    <title>SMS</title>


    <link href="css/bootstrap.css" rel="stylesheet" />

    <style>
        #headDiv {
            background-color: #5837D0;
            color: white;
            padding-top: 20px;
        }


        #lineDiv {
            background-color: #f75842;
            height: 8px;
        }
    </style>



</head>

<body>

    <div class="container">

        <div class="row" id="headDiv">
            <div class="col-12">
                <h2>Student Management System (g5)</h2>
                <p>Your digital shcool</p>
            </div>
        </div>



        <div class="row" id="lineDiv">
            <div class="col-12">

            </div>
        </div>





        <div class="row" id="bodyDiv">


            <div class="col-2">
                <?php
                include('_menu.php');
                ?>

            </div>




            <div class="col-10">
                <p> <?php echo $_SESSION['userinfo']['nic']   ?> <a href="logout.php"> Logout </a> </p>

                <h3>Manage Subjects</h3>
                <hr>

                <!-- code here -->


                <?php

                include('_function.php');

                if (isset($_POST['btnAdd'])) {
                    $subjectname = $_POST['subjectname'];
                    //db connect
                    $conn =  getDBConnection();

                    $sql = "INSERT INTO tbl_subject (subject_name) VALUES ('$subjectname')";


                    if (mysqli_query($conn, $sql)) {
                ?>
                        <div class="alert alert-success" role="alert">
                            New subject inserted successfully
                        </div>
                    <?php
                    } else {

                    ?>
                        <div class="alert alert-danger" role="alert">
                            Invalid input found
                        </div>
                <?php
                    }

                    mysqli_close($conn);
                }

                ?>

                <form action="manage-subject.php" method="post">

                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Subejct Name</label>
                        <input type="text" name="subjectname" class="form-control">
                    </div>

                    <button type="submit" name="btnAdd" class="btn btn-primary">Add Subject</button>
                </form>







                <table class="table table-success table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Subject Name</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $conn =  getDBConnection();
                        $sql = "SELECT * FROM tbl_subject ORDER BY id";

                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            // output data of each row
                            while ($row = mysqli_fetch_assoc($result)) {
                               ?>
                            

                            <tr>
                            <th scope="row"> <?php   echo $row['id']; ?> </th>
                            <td><?php   echo $row['subject_name']; ?> </td>
                            <td><a href="update-subject.php?sunname=<?php   echo $row['subject_name']; ?>&sid=<?php   echo $row['id']; ?>"> Edit </a> </td>
                        </tr>

                                <?php

                            }
                        } 


                        ?>


                     





                    </tbody>
                </table>







            </div>







        </div>






        <div class="row" id="footerDiv">
            <div class="col-12">
                <p style="text-align: center;">SMS - group5 - 2022 - sept</p>
            </div>
        </div>




    </div>


</body>

</html>