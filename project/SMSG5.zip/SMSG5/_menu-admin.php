<p>Admin</p>
<ul>
    <li>Home</li>
    <li> <a href="manage-subject.php">Manage Subjects</a>  </li>
    <li>Teacher Registration </li>
    <li>View Subject  List</li>
    <li>View Subject Students  </li>
    <li>Manage Students  </li>
</ul>