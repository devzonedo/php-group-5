<?php


function getDBConnection()
{
    // db connect 
    $servername = 'localhost';
    $username = 'root';
    $password = '123';
    $dbname = 'smsg5_db';

    $conn =  mysqli_connect($servername, $username, $password, $dbname);
    return $conn;
    
}
