<p>Student</p>
<ul>
    <li>Home</li>
    <li>Manage Classes </li>

</ul>