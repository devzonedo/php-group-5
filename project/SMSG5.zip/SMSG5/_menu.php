<p>Menu Page</p>

<?php

if($_SESSION['userinfo']['role_code'] == 'ADMIN'){
    include('_menu-admin.php');
} else if($_SESSION['userinfo']['role_code'] == 'STUDENT'){
    include('_menu-student.php');
} else if($_SESSION['userinfo']['role_code'] == 'TEACHER'){
    include('_menu-teacher.php');
}

?>