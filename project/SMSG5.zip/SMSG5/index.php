<html>

<?php
session_start();
?>


<head>
    <title>SMS</title>


    <link href="css/bootstrap.css" rel="stylesheet" />




    <style>

        #headDiv{
            background-color: #5837D0;
            color: white;
            padding-top: 20px;
        }


        #lineDiv{
            background-color: #f75842;
            height: 8px;
        }
    </style>



</head>

<body>



    <div class="container">

        <div class="row" id="headDiv">
            <div class="col-12">
                <h2>Student Management System (g5)</h2>
                <p>Your digital shcool</p>
            </div>
        </div>



        <div class="row" id="lineDiv">
            <div class="col-12">
            
            </div>
        </div>


        <div class="row" id="bodyDiv">

            <div class="col-8">
                <img src="images/undraw_true_friends_c94g.png" />
            </div>


            <div class="col-4"  style="padding-top: 80px;">

                <h3>Login</h3>




                <?php
                // isset($_POST['btnLogin']) // true 

                if(isset($_POST['btnLogin'])){


                    $nic = $_POST['nic'];
                    $pword = $_POST['pword'];
                      
                    // db connect 
                    $servername = 'localhost'; 
                    $username = 'root';
                    $password = '123';
                    $dbname = 'smsg5_db';

                    $conn =  mysqli_connect($servername , $username , $password,$dbname);

                    //echo 'DB connected..................';
                  
                    $sql = "SELECT * FROM tbl_user WHERE nic = '$nic' AND  pword = '$pword' AND status_code = 'ACTIVE'";

                    $result = mysqli_query($conn,$sql);


                    if(mysqli_num_rows($result) > 0 ){

                        while($row = mysqli_fetch_assoc($result)){


                         /*   echo $row['nic'];
                            echo $row['pword'];
                            echo $row['role_code'];
                            echo $row['status_code'];
                            echo $row['created_user'];
                            echo $row['created_datetime']; */

                            $_SESSION['userinfo'] = $row;

                            // redirect to home.php
                            header('Location: home.php');

                        }


                    }else{

                      ?>


                <div class="alert alert-danger" role="alert">
                Invalid Username or Password
                </div>

            <?php

                    }

                }
                
                ?>


                <form action="index.php" method="post">

                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">NIC</label>
                        <input type="text" name="nic" class="form-control"  >
                    </div>

                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Password</label>
                        <input type="password"  name="pword" class="form-control"  >
                    </div>

                    <button type="submit"  name="btnLogin" class="btn btn-primary">Login</button>

                </form>








                <h5> <a href="#">  Sign up  Free </a></h5>


            </div>

        </div>



        <div class="row" id="footerDiv">
            <div class="col-12">
                <p style="text-align: center;">SMS - group5 - 2022 - sept</p>
            </div>
        </div>




    </div>






    <h1>Bootstrap added</h1>
    <p>This is index of SMS Application </p>


    <div class="alert alert-primary" role="alert">
        A simple primary alert—check it out!
    </div>






</body>

</html>