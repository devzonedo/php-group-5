<html>


<?php
session_start();
?>


<head>
    <title>SMS</title>


    <link href="css/bootstrap.css" rel="stylesheet" />

    <style>

        #headDiv{
            background-color: #5837D0;
            color: white;
            padding-top: 20px;
        }


        #lineDiv{
            background-color: #f75842;
            height: 8px;
        }
    </style>



</head>

<body>

    <div class="container">

        <div class="row" id="headDiv">
            <div class="col-12">
                <h2>Student Management System (g5)</h2>
                <p>Your digital shcool</p>
            </div>
        </div>



        <div class="row" id="lineDiv">
            <div class="col-12">
        
            </div>
        </div>





        <div class="row" id="bodyDiv">

    
        <div class="col-2">
            <?php
            include('_menu.php');
            ?>

        </div>




        <div class="col-10">
        <p>   <?php   echo $_SESSION['userinfo']['nic']   ?>     <a href="logout.php">  Logout  </a>   </p>



        <!-- code here -->





        </div>







        </div>






        <div class="row" id="footerDiv">
            <div class="col-12">
                <p style="text-align: center;">SMS - group5 - 2022 - sept</p>
            </div>
        </div>




    </div>


</body>

</html>